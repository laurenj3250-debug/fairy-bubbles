import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Heart, Sparkles, TrendingUp } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { VirtualPet as VirtualPetType, Costume } from "@shared/schema";
import catImageUrl from "@assets/ChatGPT Image Oct 31, 2025, 12_29_08 PM_1761928247590.png";

export function VirtualPet() {
  const { data: pet, isLoading: petLoading } = useQuery<VirtualPetType>({
    queryKey: ["/api/pet"],
  });

  const { data: userCostumes = [] } = useQuery<any[]>({
    queryKey: ["/api/user-costumes"],
  });

  const { data: costumes = [] } = useQuery<Costume[]>({
    queryKey: ["/api/costumes"],
  });

  const updatePetMutation = useMutation({
    mutationFn: async (data: { currentCostumeId: number | null }) => {
      if (!pet) return;
      return await apiRequest(`/api/pet/${pet.id}`, "PATCH", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pet"], exact: false });
    },
  });

  if (petLoading || !pet) {
    return (
      <Card className="rounded-3xl overflow-hidden">
        <CardContent className="p-8">
          <div className="h-64 animate-pulse bg-muted rounded-3xl" />
        </CardContent>
      </Card>
    );
  }

  const currentCostume = costumes.find(c => c.id === pet.currentCostumeId);

  return (
    <Card className="rounded-3xl overflow-hidden border-0 shadow-sm bg-gradient-lagoon" data-testid="virtual-pet-card">
      <CardContent className="p-8">
        {/* Circular Pet Image */}
        <div className="flex items-center justify-center mb-8" data-testid="pet-display-container">
          <div className="relative w-48 h-48 rounded-full bg-white/60 backdrop-blur-sm border-4 border-white shadow-lg overflow-hidden">
            <img 
              src={catImageUrl} 
              alt={pet.name}
              className="w-full h-full object-cover"
              data-testid="img-pet-base"
            />
          </div>
        </div>

        {/* Pet Name and Status */}
        <div className="text-center mb-8">
          <h2 className="text-xl font-semibold text-foreground mb-2">
            Your Forest Friend
          </h2>
          <Badge variant="outline" className="rounded-full px-4 py-1.5 bg-white/60 backdrop-blur-sm border-white/80">
            <TrendingUp className="w-3.5 h-3.5 mr-1.5" />
            Growing Steadily
          </Badge>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-gradient-sunrise rounded-2xl p-4 text-center border-2 border-white/60">
            <div className="flex items-center justify-center gap-1.5 mb-1">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span className="text-3xl font-bold text-foreground">{pet.level || 1}</span>
            </div>
            <div className="text-sm font-medium text-foreground/70">Day Streak</div>
          </div>
          <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-4 text-center border-2 border-white/80">
            <div className="flex items-center justify-center gap-1.5 mb-1">
              <TrendingUp className="w-4 h-4 text-primary" />
              <span className="text-3xl font-bold text-foreground">{pet.happiness}%</span>
            </div>
            <div className="text-sm font-medium text-foreground/70">This Week</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
