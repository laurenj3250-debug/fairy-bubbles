import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HabitToggleRow } from "@/components/HabitToggleRow";
import { VirtualPet } from "@/components/VirtualPet";
import { EmptyState } from "@/components/EmptyState";
import { FAB } from "@/components/FAB";
import { Home, Calendar, List, CheckCircle, Sparkles, Zap, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Habit, HabitLog } from "@shared/schema";
import { useState, useMemo } from "react";
import { getToday, calculateStreak } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { HabitDialog } from "@/components/HabitDialog";
import { GoalDialog } from "@/components/GoalDialog";
import { HabitLogDialog } from "@/components/HabitLogDialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

type TabType = "today" | "calendar" | "todos";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<TabType>("today");
  const [habitDialogOpen, setHabitDialogOpen] = useState(false);
  const [goalDialogOpen, setGoalDialogOpen] = useState(false);
  const [habitLogDialogOpen, setHabitLogDialogOpen] = useState(false);
  const [selectedHabit, setSelectedHabit] = useState<Habit | null>(null);
  const [quickActionOpen, setQuickActionOpen] = useState(false);
  
  const { data: habits = [], isLoading: habitsLoading } = useQuery<Habit[]>({
    queryKey: ["/api/habits"],
  });

  const { data: todayLogs = [], isLoading: logsLoading } = useQuery<HabitLog[]>({
    queryKey: ["/api/habit-logs", getToday()],
    queryFn: () => fetch(`/api/habit-logs?date=${getToday()}`).then(res => res.json()),
  });

  const toggleHabitMutation = useMutation({
    mutationFn: async ({ habitId, completed }: { habitId: number; completed: boolean }) => {
      const existingLog = todayLogs.find(log => log.habitId === habitId);
      
      if (existingLog) {
        return apiRequest(`/api/habit-logs/${existingLog.id}`, "PATCH", {
          completed: !existingLog.completed,
        });
      } else {
        return apiRequest("/api/habit-logs", "POST", {
          habitId,
          date: getToday(),
          completed: true,
          note: null,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habit-logs"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/habits"], exact: false });
    },
  });

  const todayHabits = useMemo(() => {
    return habits.map(habit => {
      const log = todayLogs.find(l => l.habitId === habit.id);
      return { ...habit, completed: log?.completed || false };
    });
  }, [habits, todayLogs]);

  const currentStreak = useMemo(() => {
    const completedToday = todayHabits.filter(h => h.completed).length;
    if (completedToday === 0) return 0;
    return 1; // Simplified for now
  }, [todayHabits]);

  const completedCount = todayHabits.filter(h => h.completed).length;
  const totalCount = todayHabits.length;

  const handleToggleHabit = (habitId: number, completed: boolean) => {
    toggleHabitMutation.mutate({ habitId, completed });
  };

  const handleFabClick = () => {
    setQuickActionOpen(true);
  };

  const handleLongPress = (habit: Habit) => {
    setSelectedHabit(habit);
    setHabitLogDialogOpen(true);
  };

  const formatDate = () => {
    const date = new Date();
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };

  if (habitsLoading || logsLoading) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row gap-4 md:gap-6 p-4 md:p-6">
        <div className="w-full md:w-80">
          <Skeleton className="h-96 w-full rounded-3xl" />
        </div>
        <div className="flex-1">
          <Skeleton className="h-20 w-full rounded-3xl mb-6" />
          <Skeleton className="h-96 w-full rounded-3xl" />
        </div>
      </div>
    );
  }

  if (habits.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <EmptyState
          icon={CheckCircle}
          title="Ready to build something awesome?"
          description="Let's create your first habit and start your journey to greatness!"
          actionLabel="Start a new habit"
          onAction={handleFabClick}
        />
        <FAB onClick={handleFabClick} />
        <HabitDialog open={habitDialogOpen} onOpenChange={setHabitDialogOpen} />
        <GoalDialog open={goalDialogOpen} onOpenChange={setGoalDialogOpen} />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row gap-4 md:gap-6 p-4 md:p-6">
      {/* Left Panel - Virtual Pet */}
      <div className="w-full md:w-80 md:flex-shrink-0">
        <div className="md:sticky md:top-6 relative">
          <Star className="absolute top-8 left-8 w-6 h-6 text-yellow-400 z-10" />
          <Sparkles className="absolute top-12 right-10 w-5 h-5 text-pink-400 z-10" />
          <Star className="absolute bottom-24 right-12 w-4 h-4 text-yellow-300 z-10" />
          <VirtualPet />
        </div>
      </div>

      {/* Right Panel - Main Content */}
      <div className="flex-1 min-w-0 pb-20 md:pb-0">
        {/* Header with Greeting, Date, and Badges */}
        <Card className="rounded-3xl p-4 md:p-6 mb-4 md:mb-6" data-testid="header-card">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3 md:gap-4">
              <Avatar className="w-12 h-12 md:w-14 md:h-14">
                <AvatarFallback className="bg-primary/10 text-primary text-base md:text-lg font-semibold">AL</AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-xl md:text-2xl font-semibold" data-testid="greeting-text">
                  {getGreeting()}, Alex
                </h1>
                <p className="text-xs md:text-sm text-muted-foreground mt-0.5">
                  {formatDate()} • Keep growing!
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 md:gap-3 w-full sm:w-auto">
              <Badge variant="secondary" className="rounded-xl px-3 md:px-4 py-1.5 md:py-2 text-xs md:text-sm font-medium flex items-center gap-1.5 md:gap-2 flex-1 sm:flex-initial justify-center" data-testid="streak-badge">
                <Zap className="w-3.5 h-3.5 md:w-4 md:h-4" />
                {currentStreak} day streak
              </Badge>
              <Badge className="rounded-xl px-3 md:px-4 py-1.5 md:py-2 text-base md:text-lg font-semibold flex-1 sm:flex-initial justify-center" data-testid="completion-badge">
                {completedCount}/{totalCount}
              </Badge>
            </div>
          </div>
        </Card>

        {/* Tab Navigation */}
        <div className="flex gap-2 md:gap-3 mb-4 md:mb-6 overflow-x-auto pb-2">
          <Button
            variant={activeTab === "today" ? "default" : "ghost"}
            className={cn("rounded-full px-4 md:px-6 text-sm md:text-base whitespace-nowrap", activeTab === "today" && "shadow-md")}
            onClick={() => setActiveTab("today")}
            data-testid="tab-today"
          >
            <Home className="w-4 h-4 mr-2" />
            Today
          </Button>
          <Button
            variant={activeTab === "calendar" ? "default" : "ghost"}
            className={cn("rounded-full px-4 md:px-6 text-sm md:text-base whitespace-nowrap", activeTab === "calendar" && "shadow-md")}
            onClick={() => setActiveTab("calendar")}
            data-testid="tab-calendar"
          >
            <Calendar className="w-4 h-4 mr-2" />
            Calendar
          </Button>
          <Button
            variant={activeTab === "todos" ? "default" : "ghost"}
            className={cn("rounded-full px-4 md:px-6 text-sm md:text-base whitespace-nowrap", activeTab === "todos" && "shadow-md")}
            onClick={() => setActiveTab("todos")}
            data-testid="tab-todos"
          >
            <List className="w-4 h-4 mr-2" />
            To-Do
          </Button>
        </div>

        {/* Today's Habits Panel */}
        <Card className="rounded-3xl" data-testid="today-panel">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-4">
            <CardTitle className="flex items-center gap-2">
              Today's Habits
              <span className="text-sm font-normal text-muted-foreground">
                {completedCount}/{totalCount}
              </span>
            </CardTitle>
            <Sparkles className="w-5 h-5 text-yellow-400" />
          </CardHeader>
          <CardContent className="space-y-2">
            {todayHabits.map(habit => (
              <HabitToggleRow
                key={habit.id}
                title={habit.title}
                icon={habit.icon}
                color={habit.color}
                completed={habit.completed}
                onToggle={() => handleToggleHabit(habit.id, habit.completed)}
                onLongPress={() => handleLongPress(habit)}
              />
            ))}
          </CardContent>
        </Card>
      </div>

      <FAB onClick={handleFabClick} />
      
      <Sheet open={quickActionOpen} onOpenChange={setQuickActionOpen}>
        <SheetContent side="bottom" className="h-auto rounded-t-3xl">
          <SheetHeader>
            <SheetTitle>What would you like to do?</SheetTitle>
          </SheetHeader>
          <div className="grid gap-3 py-4">
            <Button
              onClick={() => {
                setQuickActionOpen(false);
                setHabitDialogOpen(true);
              }}
              className="w-full justify-start rounded-xl"
              variant="outline"
              data-testid="button-create-habit"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Start a new habit
            </Button>
            <Button
              onClick={() => {
                setQuickActionOpen(false);
                setGoalDialogOpen(true);
              }}
              className="w-full justify-start rounded-xl"
              variant="outline"
              data-testid="button-create-goal"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Dream big
            </Button>
          </div>
        </SheetContent>
      </Sheet>
      
      <HabitDialog open={habitDialogOpen} onOpenChange={setHabitDialogOpen} />
      <GoalDialog open={goalDialogOpen} onOpenChange={setGoalDialogOpen} />
      <HabitLogDialog open={habitLogDialogOpen} onOpenChange={setHabitLogDialogOpen} habit={selectedHabit} />
    </div>
  );
}
